# email_verification
verfiy if the email is legit
